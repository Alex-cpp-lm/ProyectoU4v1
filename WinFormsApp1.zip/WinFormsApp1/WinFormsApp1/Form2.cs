﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        
        private int mes;
        private int año;
        private int empleadoId;
        private DAOBase db;

        public Form2(int mes, int año, int empleadoId)
        {

            InitializeComponent();
            lblyear.Text = "";
            lblMes.Text = "";

            this.mes = mes;
            this.año = año;
            this.empleadoId = empleadoId;
            db = new DAOBase();



            lblMes.Text = mes.ToString();
            lblyear.Text = año.ToString();

            llenarReportePorEmpleado();
            llenarReporteVentasMes();

            // cargar los dos gridview segun el mes, año.
            //el primer gridvew, es de todos los datos de la venta
            //y el segundo gridview es reporte de ventas por empleado
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = empleadoId; //toma el id del empleado para la siguente ventana
            Form3 form = new Form3(id, año, mes);
            form.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            

           
        }


        

        // Llenar dataGridView2 (Reporte de Ventas por Empleado)
        public void llenarReportePorEmpleado()
        {
            try
            {
                
                DataTable datosEmpleado = db.obtenerReportePorEmpleadoVista(mes, año, dataGridView2);

                
                if (datosEmpleado.Rows.Count > 0)
                {
                    
                    if (dataGridView2.Columns["EmpleadoVentas"] == null)
                    {
                        dataGridView2.Columns.Add("EmpleadoVentas", "Empleado");
                        dataGridView2.Columns.Add("TotalVentas", "Total");
                        dataGridView2.Columns.Add("cant_VentasE", "Cant. Ventas");
                    }

                   
                    dataGridView2.DataSource = datosEmpleado;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos para el reporte por empleado.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el reporte de empleado: {ex.Message}");
            }
        }

        // Llenar dataGridView1 (Reporte de Ventas por Mes :D)
        public void llenarReporteVentasMes()
        {
            try
            {
                
                DataTable datosMes = db.obtenerReporteVentasMesVista(mes, año, dataGridView1);

               
                if (datosMes.Rows.Count > 0)
                {
                    
                    if (dataGridView1.Columns["Folio"] == null)
                    {
                        dataGridView1.Columns.Add("Folio", "Folio");
                        dataGridView1.Columns.Add("Fecha", "Fecha");
                        dataGridView1.Columns.Add("Cliente", "Cliente");
                        dataGridView1.Columns.Add("Empleado", "Empleado");
                        dataGridView1.Columns.Add("Total", "Total");
                        dataGridView1.Columns.Add("Cant_Detalles", "Cant. Detalles");
                    }

                    // Asignar la fuente de datos
                    dataGridView1.DataSource = datosMes;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos para el reporte de ventas por mes.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el reporte de ventas por mes: {ex.Message}");
            }
        }

    }
}
