﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            loginP = new Panel();
            label5 = new Label();
            label4 = new Label();
            button1 = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            dataGridView2 = new DataGridView();
            perfilP = new Panel();
            idEmp = new Label();
            sueldo = new Label();
            usuario = new Label();
            nombre_apellidos = new Label();
            pictureBox1 = new PictureBox();
            productoP = new Panel();
            label8 = new Label();
            numericUpDown1 = new NumericUpDown();
            eliminarP = new Button();
            agregarB = new Button();
            precioPr = new Label();
            cantPr = new Label();
            nombrePr = new Label();
            codigoPr = new Label();
            productoImagen = new PictureBox();
            totalT = new Label();
            label7 = new Label();
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            cobroP = new Button();
            cancelar = new Button();
            panel4 = new Panel();
            textBox3 = new TextBox();
            label6 = new Label();
            busquedaa = new DataGridView();
            busquedaP = new Panel();
            label9 = new Label();
            textBox4 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            panel1 = new Panel();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            direccionClienteBox = new TextBox();
            apellidoClienteBox = new TextBox();
            nombreClienteBox = new TextBox();
            label12 = new Label();
            button3 = new Button();
            seleccionarCliente = new Button();
            clienteGrid = new DataGridView();
            textBox5 = new TextBox();
            agregarCliente = new Button();
            label17 = new Label();
            label18 = new Label();
            iva = new Label();
            subtotal = new Label();
            infoVenta = new Label();
            label21 = new Label();
            generarReporte = new Button();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            loginP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            perfilP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            productoP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productoImagen).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)busquedaa).BeginInit();
            busquedaP.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)clienteGrid).BeginInit();
            SuspendLayout();
            // 
            // loginP
            // 
            loginP.Controls.Add(label5);
            loginP.Controls.Add(label4);
            loginP.Controls.Add(button1);
            loginP.Controls.Add(label3);
            loginP.Controls.Add(label2);
            loginP.Controls.Add(label1);
            loginP.Controls.Add(textBox2);
            loginP.Controls.Add(textBox1);
            loginP.Location = new Point(5, 5);
            loginP.Margin = new Padding(3, 4, 3, 4);
            loginP.Name = "loginP";
            loginP.Size = new Size(267, 373);
            loginP.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Red;
            label5.Location = new Point(3, 243);
            label5.Name = "label5";
            label5.Size = new Size(289, 20);
            label5.TabIndex = 7;
            label5.Text = "CONTRASEÑA O USUARIO INCORRECTOS!";
            label5.Visible = false;
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 301);
            label4.Name = "label4";
            label4.Size = new Size(179, 40);
            label4.TabIndex = 6;
            label4.Text = "si olvidaste tu contraseña,\r\n ve con tu gerente.";
            label4.Visible = false;
            // 
            // button1
            // 
            button1.Location = new Point(86, 267);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(86, 31);
            button1.TabIndex = 5;
            button1.Text = "INGRESAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(57, 167);
            label3.Name = "label3";
            label3.Size = new Size(86, 20);
            label3.TabIndex = 4;
            label3.Text = "Contraseña:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(59, 76);
            label2.Name = "label2";
            label2.Size = new Size(62, 20);
            label2.TabIndex = 3;
            label2.Text = "Usuario:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(43, 16);
            label1.Name = "label1";
            label1.Size = new Size(197, 34);
            label1.TabIndex = 2;
            label1.Text = "INICIO DE SESION";
            label1.Click += label1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(57, 191);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(159, 27);
            textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(57, 107);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(159, 27);
            textBox1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.ColumnHeader;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.EditMode = DataGridViewEditMode.EditOnKeystroke;
            dataGridView2.Location = new Point(2, 19);
            dataGridView2.Margin = new Padding(3, 4, 3, 4);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(295, 395);
            dataGridView2.TabIndex = 8;
            dataGridView2.Visible = false;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // perfilP
            // 
            perfilP.Controls.Add(idEmp);
            perfilP.Controls.Add(sueldo);
            perfilP.Controls.Add(usuario);
            perfilP.Controls.Add(nombre_apellidos);
            perfilP.Controls.Add(pictureBox1);
            perfilP.Enabled = false;
            perfilP.Location = new Point(14, 16);
            perfilP.Margin = new Padding(3, 4, 3, 4);
            perfilP.Name = "perfilP";
            perfilP.Size = new Size(274, 105);
            perfilP.TabIndex = 1;
            perfilP.Visible = false;
            perfilP.MouseClick += perfilP_MouseClick;
            perfilP.MouseEnter += perfilP_MouseEnter;
            perfilP.MouseLeave += perfilP_MouseLeave;
            // 
            // idEmp
            // 
            idEmp.AutoSize = true;
            idEmp.Location = new Point(13, 143);
            idEmp.Name = "idEmp";
            idEmp.Size = new Size(50, 20);
            idEmp.TabIndex = 0;
            idEmp.Text = "label7";
            // 
            // sueldo
            // 
            sueldo.AutoSize = true;
            sueldo.Location = new Point(13, 109);
            sueldo.Name = "sueldo";
            sueldo.Size = new Size(50, 20);
            sueldo.TabIndex = 3;
            sueldo.Text = "label7";
            sueldo.Click += label7_Click;
            // 
            // usuario
            // 
            usuario.AutoSize = true;
            usuario.Location = new Point(74, 49);
            usuario.Name = "usuario";
            usuario.Size = new Size(71, 20);
            usuario.TabIndex = 2;
            usuario.Text = "USUARIO";
            // 
            // nombre_apellidos
            // 
            nombre_apellidos.AutoSize = true;
            nombre_apellidos.Location = new Point(74, 16);
            nombre_apellidos.Name = "nombre_apellidos";
            nombre_apellidos.Size = new Size(70, 20);
            nombre_apellidos.TabIndex = 1;
            nombre_apellidos.Text = "NOMBRE";
            nombre_apellidos.Click += label6_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 4);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 89);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // productoP
            // 
            productoP.Controls.Add(label8);
            productoP.Controls.Add(numericUpDown1);
            productoP.Controls.Add(eliminarP);
            productoP.Controls.Add(agregarB);
            productoP.Controls.Add(precioPr);
            productoP.Controls.Add(cantPr);
            productoP.Controls.Add(nombrePr);
            productoP.Controls.Add(codigoPr);
            productoP.Controls.Add(productoImagen);
            productoP.Enabled = false;
            productoP.Location = new Point(305, 20);
            productoP.Margin = new Padding(3, 4, 3, 4);
            productoP.Name = "productoP";
            productoP.Size = new Size(395, 148);
            productoP.TabIndex = 6;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(274, 112);
            label8.Name = "label8";
            label8.Size = new Size(42, 20);
            label8.TabIndex = 8;
            label8.Text = "Cant:";
            label8.Click += label8_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(321, 109);
            numericUpDown1.Margin = new Padding(3, 4, 3, 4);
            numericUpDown1.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numericUpDown1.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(51, 27);
            numericUpDown1.TabIndex = 7;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // eliminarP
            // 
            eliminarP.Location = new Point(269, 71);
            eliminarP.Margin = new Padding(3, 4, 3, 4);
            eliminarP.Name = "eliminarP";
            eliminarP.Size = new Size(112, 31);
            eliminarP.TabIndex = 6;
            eliminarP.Text = "ELIMINAR (F10)";
            eliminarP.UseVisualStyleBackColor = true;
            eliminarP.Click += eliminarP_Click;
            // 
            // agregarB
            // 
            agregarB.Location = new Point(269, 29);
            agregarB.Margin = new Padding(3, 4, 3, 4);
            agregarB.Name = "agregarB";
            agregarB.Size = new Size(112, 31);
            agregarB.TabIndex = 5;
            agregarB.Text = "AGREGAR (F9)";
            agregarB.UseVisualStyleBackColor = true;
            agregarB.Click += agregarB_Click;
            // 
            // precioPr
            // 
            precioPr.AutoSize = true;
            precioPr.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            precioPr.Location = new Point(105, 72);
            precioPr.Name = "precioPr";
            precioPr.Size = new Size(168, 37);
            precioPr.TabIndex = 4;
            precioPr.Text = "PRECIO $0.0";
            // 
            // cantPr
            // 
            cantPr.AutoSize = true;
            cantPr.Location = new Point(105, 49);
            cantPr.Name = "cantPr";
            cantPr.Size = new Size(157, 20);
            cantPr.TabIndex = 3;
            cantPr.Text = "cantidad en inventario";
            // 
            // nombrePr
            // 
            nombrePr.AutoSize = true;
            nombrePr.Location = new Point(177, 5);
            nombrePr.Name = "nombrePr";
            nombrePr.Size = new Size(151, 20);
            nombrePr.TabIndex = 2;
            nombrePr.Text = "nombre del producto";
            // 
            // codigoPr
            // 
            codigoPr.AutoSize = true;
            codigoPr.Font = new Font("Segoe UI", 8.25F, FontStyle.Italic, GraphicsUnit.Point, 0);
            codigoPr.Location = new Point(16, 4);
            codigoPr.Name = "codigoPr";
            codigoPr.Size = new Size(134, 19);
            codigoPr.TabIndex = 1;
            codigoPr.Text = "codigo del producto";
            // 
            // productoImagen
            // 
            productoImagen.Location = new Point(16, 24);
            productoImagen.Margin = new Padding(3, 4, 3, 4);
            productoImagen.Name = "productoImagen";
            productoImagen.Size = new Size(82, 105);
            productoImagen.SizeMode = PictureBoxSizeMode.StretchImage;
            productoImagen.TabIndex = 0;
            productoImagen.TabStop = false;
            // 
            // totalT
            // 
            totalT.AutoSize = true;
            totalT.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            totalT.Location = new Point(961, 700);
            totalT.Name = "totalT";
            totalT.Size = new Size(73, 41);
            totalT.TabIndex = 1;
            totalT.Text = "$0.0";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(872, 700);
            label7.Name = "label7";
            label7.Size = new Size(105, 37);
            label7.TabIndex = 0;
            label7.Text = "TOTAL:";
            label7.Click += label7_Click_1;
            // 
            // panel2
            // 
            panel2.Controls.Add(dataGridView1);
            panel2.Location = new Point(321, 187);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(654, 361);
            panel2.TabIndex = 7;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(653, 361);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // cobroP
            // 
            cobroP.Location = new Point(1031, 769);
            cobroP.Margin = new Padding(3, 4, 3, 4);
            cobroP.Name = "cobroP";
            cobroP.Size = new Size(119, 151);
            cobroP.TabIndex = 0;
            cobroP.Text = "COBRAR(F12)";
            cobroP.UseVisualStyleBackColor = true;
            cobroP.Click += cobro_Click;
            // 
            // cancelar
            // 
            cancelar.Location = new Point(872, 769);
            cancelar.Margin = new Padding(3, 4, 3, 4);
            cancelar.Name = "cancelar";
            cancelar.Size = new Size(123, 151);
            cancelar.TabIndex = 1;
            cancelar.Text = "CANCELAR(F11)";
            cancelar.UseVisualStyleBackColor = true;
            cancelar.Click += cancelar_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(dataGridView2);
            panel4.Controls.Add(loginP);
            panel4.Location = new Point(13, 159);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(302, 389);
            panel4.TabIndex = 8;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(14, 4);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(186, 27);
            textBox3.TabIndex = 0;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(207, 9);
            label6.Name = "label6";
            label6.Size = new Size(144, 20);
            label6.TabIndex = 1;
            label6.Text = "BUSCAR PRODUCTO";
            label6.Click += label6_Click_2;
            // 
            // busquedaa
            // 
            busquedaa.AllowUserToAddRows = false;
            busquedaa.AllowUserToDeleteRows = false;
            busquedaa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            busquedaa.Location = new Point(2, 43);
            busquedaa.Margin = new Padding(3, 4, 3, 4);
            busquedaa.Name = "busquedaa";
            busquedaa.ReadOnly = true;
            busquedaa.RowHeadersWidth = 51;
            busquedaa.Size = new Size(418, 120);
            busquedaa.TabIndex = 0;
            busquedaa.CellClick += busquedaa_CellClick;
            // 
            // busquedaP
            // 
            busquedaP.Controls.Add(busquedaa);
            busquedaP.Controls.Add(label6);
            busquedaP.Controls.Add(textBox3);
            busquedaP.Enabled = false;
            busquedaP.Location = new Point(707, 16);
            busquedaP.Margin = new Padding(3, 4, 3, 4);
            busquedaP.Name = "busquedaP";
            busquedaP.Size = new Size(418, 164);
            busquedaP.TabIndex = 2;
            busquedaP.Paint += busquedaP_Paint;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(626, 600);
            label9.Name = "label9";
            label9.Size = new Size(236, 20);
            label9.TabIndex = 9;
            label9.Text = "Descripcion de la venta (opcional)";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(626, 625);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(215, 93);
            textBox4.TabIndex = 10;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(17, 139);
            label10.Name = "label10";
            label10.Size = new Size(115, 20);
            label10.TabIndex = 11;
            label10.Text = "Ventas recientes";
            label10.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(24, 20);
            label11.Name = "label11";
            label11.Size = new Size(122, 37);
            label11.TabIndex = 12;
            label11.Text = "CLIENTE";
            label11.Click += label11_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(direccionClienteBox);
            panel1.Controls.Add(apellidoClienteBox);
            panel1.Controls.Add(nombreClienteBox);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(seleccionarCliente);
            panel1.Controls.Add(clienteGrid);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(agregarCliente);
            panel1.Controls.Add(label11);
            panel1.Location = new Point(13, 580);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(607, 340);
            panel1.TabIndex = 13;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(185, 320);
            label16.Name = "label16";
            label16.Size = new Size(85, 20);
            label16.TabIndex = 22;
            label16.Text = "(sin cliente)";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(415, 209);
            label15.Name = "label15";
            label15.Size = new Size(75, 20);
            label15.TabIndex = 21;
            label15.Text = "Dirección:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(415, 140);
            label14.Name = "label14";
            label14.Size = new Size(69, 20);
            label14.TabIndex = 20;
            label14.Text = "Apellido:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(415, 75);
            label13.Name = "label13";
            label13.Size = new Size(67, 20);
            label13.TabIndex = 19;
            label13.Text = "Nombre:";
            // 
            // direccionClienteBox
            // 
            direccionClienteBox.Location = new Point(415, 233);
            direccionClienteBox.Margin = new Padding(3, 4, 3, 4);
            direccionClienteBox.Name = "direccionClienteBox";
            direccionClienteBox.Size = new Size(171, 27);
            direccionClienteBox.TabIndex = 18;
            // 
            // apellidoClienteBox
            // 
            apellidoClienteBox.Location = new Point(415, 164);
            apellidoClienteBox.Margin = new Padding(3, 4, 3, 4);
            apellidoClienteBox.Name = "apellidoClienteBox";
            apellidoClienteBox.Size = new Size(171, 27);
            apellidoClienteBox.TabIndex = 17;
            // 
            // nombreClienteBox
            // 
            nombreClienteBox.Location = new Point(415, 103);
            nombreClienteBox.Margin = new Padding(3, 4, 3, 4);
            nombreClienteBox.Name = "nombreClienteBox";
            nombreClienteBox.Size = new Size(171, 27);
            nombreClienteBox.TabIndex = 16;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(455, 20);
            label12.Name = "label12";
            label12.Size = new Size(110, 37);
            label12.TabIndex = 15;
            label12.Text = "NUEVO";
            label12.Click += label12_Click;
            // 
            // button3
            // 
            button3.Location = new Point(175, 291);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(101, 31);
            button3.TabIndex = 14;
            button3.Text = "MOSTRADOR";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // seleccionarCliente
            // 
            seleccionarCliente.Location = new Point(21, 291);
            seleccionarCliente.Margin = new Padding(3, 4, 3, 4);
            seleccionarCliente.Name = "seleccionarCliente";
            seleccionarCliente.Size = new Size(141, 31);
            seleccionarCliente.TabIndex = 14;
            seleccionarCliente.Text = "SELECCIONAR";
            seleccionarCliente.UseVisualStyleBackColor = true;
            seleccionarCliente.Click += seleccionarCliente_Click;
            // 
            // clienteGrid
            // 
            clienteGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            clienteGrid.Location = new Point(24, 103);
            clienteGrid.Margin = new Padding(3, 4, 3, 4);
            clienteGrid.Name = "clienteGrid";
            clienteGrid.RowHeadersWidth = 51;
            clienteGrid.Size = new Size(367, 161);
            clienteGrid.TabIndex = 14;
            clienteGrid.CellClick += clienteGrid_CellClick;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(21, 64);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(150, 27);
            textBox5.TabIndex = 14;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // agregarCliente
            // 
            agregarCliente.Location = new Point(415, 272);
            agregarCliente.Margin = new Padding(3, 4, 3, 4);
            agregarCliente.Name = "agregarCliente";
            agregarCliente.Size = new Size(171, 43);
            agregarCliente.TabIndex = 14;
            agregarCliente.Text = "AGREGAR";
            agregarCliente.UseVisualStyleBackColor = true;
            agregarCliente.Click += agregarCliente_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label17.Location = new Point(872, 660);
            label17.Name = "label17";
            label17.Size = new Size(70, 37);
            label17.TabIndex = 14;
            label17.Text = "IVA:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label18.Location = new Point(872, 620);
            label18.Name = "label18";
            label18.Size = new Size(162, 37);
            label18.TabIndex = 15;
            label18.Text = "SUBTOTAL:";
            // 
            // iva
            // 
            iva.AutoSize = true;
            iva.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            iva.Location = new Point(929, 660);
            iva.Name = "iva";
            iva.Size = new Size(73, 41);
            iva.TabIndex = 16;
            iva.Text = "$0.0";
            // 
            // subtotal
            // 
            subtotal.AutoSize = true;
            subtotal.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            subtotal.Location = new Point(1002, 617);
            subtotal.Name = "subtotal";
            subtotal.Size = new Size(73, 41);
            subtotal.TabIndex = 17;
            subtotal.Text = "$0.0";
            // 
            // infoVenta
            // 
            infoVenta.AutoSize = true;
            infoVenta.Location = new Point(637, 748);
            infoVenta.Name = "infoVenta";
            infoVenta.Size = new Size(201, 20);
            infoVenta.TabIndex = 18;
            infoVenta.Text = "Cliente: NaN Empleado: NaN\r\n";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(21, 563);
            label21.Name = "label21";
            label21.Size = new Size(72, 20);
            label21.TabIndex = 21;
            label21.Text = "REPORTE:";
            label21.Click += label21_Click;
            // 
            // generarReporte
            // 
            generarReporte.Location = new Point(247, 555);
            generarReporte.Margin = new Padding(3, 4, 3, 4);
            generarReporte.Name = "generarReporte";
            generarReporte.Size = new Size(86, 31);
            generarReporte.TabIndex = 22;
            generarReporte.Text = "GENERAR";
            generarReporte.UseVisualStyleBackColor = true;
            generarReporte.Click += generarReporte_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" });
            comboBox1.Location = new Point(99, 559);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(60, 28);
            comboBox1.TabIndex = 23;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "2024", "2023", "2022", "2021", "2019", "2018", "2017" });
            comboBox2.Location = new Point(165, 558);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(69, 28);
            comboBox2.TabIndex = 24;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1164, 813);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(generarReporte);
            Controls.Add(label21);
            Controls.Add(infoVenta);
            Controls.Add(subtotal);
            Controls.Add(iva);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(panel1);
            Controls.Add(label10);
            Controls.Add(textBox4);
            Controls.Add(label9);
            Controls.Add(panel4);
            Controls.Add(totalT);
            Controls.Add(cobroP);
            Controls.Add(label7);
            Controls.Add(cancelar);
            Controls.Add(panel2);
            Controls.Add(productoP);
            Controls.Add(busquedaP);
            Controls.Add(perfilP);
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Form1";
            FormClosed += Form1_FormClosed;
            Load += Form1_Load;
            KeyUp += Form1_KeyUp;
            loginP.ResumeLayout(false);
            loginP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            perfilP.ResumeLayout(false);
            perfilP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            productoP.ResumeLayout(false);
            productoP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)productoImagen).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)busquedaa).EndInit();
            busquedaP.ResumeLayout(false);
            busquedaP.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)clienteGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel loginP;
        private Label label1;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label3;
        private Label label2;
        private Label label4;
        private Button button1;
        private Panel perfilP;
        private Label label5;
        private PictureBox pictureBox1;
        private Label nombre_apellidos;
        private Label usuario;
        private Label sueldo;
        private Label idEmp;
        private Label totalT;
        private Label label7;
        private Panel productoP;
        private Label nombrePr;
        private Label codigoPr;
        private PictureBox productoImagen;
        private Label cantPr;
        private Label precioPr;
        private Button agregarB;
        private Button eliminarP;
        private NumericUpDown numericUpDown1;
        private Label label8;
        private Panel panel2;
        private DataGridView dataGridView1;
        private Button cobroP;
        private Button cancelar;
        private DataGridView dataGridView2;
        private Panel panel4;
        private TextBox textBox3;
        private Label label6;
        private DataGridView busquedaa;
        private Panel busquedaP;
        private Label label9;
        private TextBox textBox4;
        private Label label10;
        private Label label11;
        private Panel panel1;
        private DataGridView clienteGrid;
        private TextBox textBox5;
        private Button agregarCliente;
        private Button button3;
        private Button seleccionarCliente;
        private Label label12;
        private TextBox direccionClienteBox;
        private TextBox apellidoClienteBox;
        private TextBox nombreClienteBox;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label iva;
        private Label subtotal;
        private Label infoVenta;
        private Label label21;
        private Button generarReporte;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
    }
}
