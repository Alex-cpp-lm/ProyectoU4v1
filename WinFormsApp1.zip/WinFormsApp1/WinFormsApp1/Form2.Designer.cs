﻿namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            dataGridView2 = new DataGridView();
            label4 = new Label();
            button1 = new Button();
            label5 = new Label();
            lblMes = new Label();
            lblyear = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 90);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(927, 300);
            dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Simple Outline Pat", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label1.Location = new Point(12, 34);
            label1.Name = "label1";
            label1.Size = new Size(282, 39);
            label1.TabIndex = 1;
            label1.Text = "Reporte de Ventas: ";
            label1.Click += label1_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Simple Outline Pat", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label2.Location = new Point(733, 9);
            label2.Name = "label2";
            label2.Size = new Size(85, 39);
            label2.TabIndex = 2;
            label2.Text = "Año: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Simple Outline Pat", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label3.Location = new Point(12, 443);
            label3.Name = "label3";
            label3.Size = new Size(469, 39);
            label3.TabIndex = 5;
            label3.Text = "Reporte de ventas por empleado: ";
            label3.Click += label3_Click;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(12, 485);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(586, 285);
            dataGridView2.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Simple Outline Pat", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label4.Location = new Point(511, 9);
            label4.Name = "label4";
            label4.Size = new Size(87, 39);
            label4.TabIndex = 7;
            label4.Text = "Mes: ";
            // 
            // button1
            // 
            button1.Location = new Point(813, 524);
            button1.Name = "button1";
            button1.Size = new Size(126, 40);
            button1.TabIndex = 8;
            button1.Text = "Generar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(707, 485);
            label5.Name = "label5";
            label5.Size = new Size(232, 20);
            label5.TabIndex = 9;
            label5.Text = "Reporte de ventas trimestrales: ";
            // 
            // lblMes
            // 
            lblMes.AutoSize = true;
            lblMes.Location = new Point(604, 21);
            lblMes.Name = "lblMes";
            lblMes.Size = new Size(50, 20);
            lblMes.TabIndex = 10;
            lblMes.Text = "label6";
            // 
            // lblyear
            // 
            lblyear.AutoSize = true;
            lblyear.Location = new Point(824, 21);
            lblyear.Name = "lblyear";
            lblyear.Size = new Size(50, 20);
            lblyear.TabIndex = 11;
            lblyear.Text = "label7";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(963, 782);
            Controls.Add(lblyear);
            Controls.Add(lblMes);
            Controls.Add(label5);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(dataGridView2);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private DataGridView dataGridView2;
        private Label label4;
        private Button button1;
        private Label label5;
        private Label lblMes;
        private Label lblyear;
    }
}