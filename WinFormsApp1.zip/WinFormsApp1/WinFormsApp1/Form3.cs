﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        private int mes;
        private int año;
        private int empleadoId;
        DAOBase x;
        public Form3(int idEmpleado, int año, int mes)
        {
            InitializeComponent();
            this.empleadoId = idEmpleado;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            x = new DAOBase();

            DataTable datos = x.obtenerReporteTrimestralVista(año, dataGridView1);

            
            if (datos != null)
            {
               
                dataGridView1.DataSource = datos;

                if (dataGridView1.Columns["Producto"] != null) 
                { 
                    dataGridView1.Columns["Producto"].HeaderText = "Producto"; 
                }
                if (dataGridView1.Columns["Trim_1"] != null) 
                { 
                    dataGridView1.Columns["Trim_1"].HeaderText = "Trim1";
                }
                if (dataGridView1.Columns["Trim_2"] != null)
                { 
                    dataGridView1.Columns["Trim_2"].HeaderText = "Trim2"; 
                }
                if (dataGridView1.Columns["Trim_3"] != null)
                {
                    dataGridView1.Columns["Trim_3"].HeaderText = "Trim3";
                }
            else
            {
                MessageBox.Show("No se pudieron cargar los datos del reporte trimestral :(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
    }
}
